using System.Text.Json;

namespace WpfFaceLogin
{
    /// <summary>
    /// 设备推送过来的识别记录（对应文档 3.2.4 识别记录上报的 params）
    /// </summary>
    public class RecognitionRecord
    {
        /// <summary>method 字段，例如 things.event.post.record:recognition</summary>
        public string Method { get; set; } = "";

        /// <summary>上报任务 ID</summary>
        public string TaskId { get; set; } = "";

        /// <summary>识别状态：0 失败 / 1 成功</summary>
        public int Status { get; set; }

        /// <summary>通行状态：0 失败 / 1 成功 / 2 平台决策</summary>
        public int PassStatus { get; set; }

        /// <summary>人员 ID（这就是设备里的“账号id”）</summary>
        public string PersonId { get; set; } = "";

        /// <summary>人员类型：0 设备人员ID / 1 平台人员ID</summary>
        public int PersonIdType { get; set; }

        /// <summary>人员编号（工号），通常可作为登录账号</summary>
        public string PersonNumber { get; set; } = "";

        /// <summary>姓名</summary>
        public string Name { get; set; } = "";

        /// <summary>识别时间 YYYY-MM-DD hh:mm:ss:xxxx</summary>
        public string Time { get; set; } = "";

        /// <summary>卡号</summary>
        public string CardNumber { get; set; } = "";
    }

    /// <summary>
    /// 大小写不敏感的 JSON 读取辅助（文档示例字段名大小写不统一）
    /// </summary>
    internal static class JsonHelper
    {
        public static string GetStr(JsonElement e, string name)
        {
            foreach (var p in e.EnumerateObject())
                if (string.Equals(p.Name, name, StringComparison.OrdinalIgnoreCase))
                    return p.Value.ValueKind == JsonValueKind.String ? p.Value.GetString() ?? "" : p.Value.ToString();
            return "";
        }

        public static int GetInt(JsonElement e, string name)
        {
            foreach (var p in e.EnumerateObject())
                if (string.Equals(p.Name, name, StringComparison.OrdinalIgnoreCase))
                    return p.Value.ValueKind == JsonValueKind.Number ? p.Value.GetInt32() : 0;
            return 0;
        }
    }
}
