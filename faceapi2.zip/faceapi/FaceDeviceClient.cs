using System;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace WpfFaceLogin
{
    /// <summary>
    /// 与设备交互的客户端（平台 -> 终端下发，对应文档 3.3 / 2.2.7）
    /// 主要用途：通过“平台握手”告诉设备，把识别记录推送到哪个地址（你的 WPF）。
    /// 如果你已经在设备的 Web 管理页配好第三方平台地址，可以不用这段代码。
    /// </summary>
    public static class FaceDeviceClient
    {
        /// <summary>
        /// 平台握手：通知设备把识别事件推送到 platformUrl:platformPort
        /// </summary>
        /// <param name="deviceIp">设备 IP，例如 192.168.252.111</param>
        /// <param name="devicePort">设备端口，例如 8098</param>
        /// <param name="platformUrl">你电脑的局域网 IP，例如 192.168.252.50</param>
        /// <param name="platformPort">你 WPF 监听的端口，例如 8088</param>
        /// <param name="deviceNum">设备序列号（可在设备背面/Web 管理页获取）</param>
        public static async Task<bool> HandShakeAsync(string deviceIp, int devicePort,
            string platformUrl, int platformPort, string deviceNum)
        {
            var timestamp = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds().ToString();
            // 签名校验：SHA256(timestamp + deviceNum)，见文档 2.4
            var sign = Sha256Hex(timestamp + deviceNum).ToLower();

            var payload = new
            {
                requestId = Guid.NewGuid().ToString("N"),
                timestamp,
                method = "things.action.exec.system:handShake",
                deviceNum,
                sign,
                @params = new
                {
                    platformUrl,
                    platformPort,
                    heartbeatTime = 10
                }
            };

            var json = JsonSerializer.Serialize(payload);
            using var client = new HttpClient { Timeout = TimeSpan.FromSeconds(10) };
            var url = $"http://{deviceIp}:{devicePort}/service/action/systemHandShake";
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var resp = await client.PostAsync(url, content);
            return resp.IsSuccessStatusCode;
        }

        private static string Sha256Hex(string input)
        {
            using var sha = SHA256.Create();
            var bytes = sha.ComputeHash(Encoding.UTF8.GetBytes(input));
            var sb = new StringBuilder();
            foreach (var b in bytes) sb.Append(b.ToString("x2"));
            return sb.ToString();
        }
    }
}
