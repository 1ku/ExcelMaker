// =========================================================================
// 人脸识别终端 HTTP 监听 —— 把下面整段贴进你现有的  LoginWindow  类内部即可
//
// 需要确认 LoginWindow.xaml.cs 文件顶部有以下 using（没有就加上）：
//   using System;
//   using System.IO;
//   using System.Net;
//   using System.Text;
//   using System.Text.Json;
//   using System.Security.Cryptography;
//   using System.Threading;
//   using System.Threading.Tasks;
//
// 然后在你现有的 Window.Loaded 事件里调用  StartFaceListener();
// 在 Window.Closing 事件里调用  StopFaceListener();
// 订阅事件拿到账号：  FaceRecognized += (pid, num, name) => { ... };
// =========================================================================

// ---------- 1. 配置（按需修改）----------
private const int    FaceListenPort  = 8088;                    // 本机监听端口，需与设备配置的“第三方平台端口”一致
private const string FacePlatformUrl = "192.168.252.50";        // 你电脑的局域网 IP（替换成真实 IP）
private const string FaceDeviceIp    = "192.168.252.111";       // 设备 IP（你提供）
private const int    FaceDevicePort  = 8098;                    // 设备端口（你提供）
private const string FaceDeviceNum   = "B0100120210221900001";  // 设备序列号（仅握手用到，可留空）

// ---------- 2. 刷脸识别成功事件 ----------
// 参数：personId=人员ID(账号)  personNumber=工号  name=姓名
public event Action<string, string, string> FaceRecognized;

// ---------- 3. 内部字段 ----------
private HttpListener _faceListener;
private CancellationTokenSource _faceCts;

// ---------- 4. 启动监听（在 Window.Loaded 里调用一次）----------
public void StartFaceListener()
{
    if (_faceListener != null) return;
    try
    {
        _faceListener = new HttpListener();
        _faceListener.Prefixes.Add("http://+:" + FaceListenPort + "/");
        _faceListener.Start();
        _faceCts = new CancellationTokenSource();
        _ = Task.Run(() => FaceListenLoop(_faceCts.Token));

        // 可选：通知设备把识别记录推送到本机（若已在设备 Web 页配置好，可删掉下面这行）
        _ = FaceRegisterToDeviceAsync();
    }
    catch (HttpListenerException ex) when (ex.ErrorCode == 5)
    {
        // 权限不足：请用管理员身份运行，或管理员 cmd 执行：
        // netsh http add urlacl url=http://+:8088/ user=Everyone
        System.Windows.MessageBox.Show("人脸监听启动失败：请用管理员身份运行，或先执行 netsh 授权。");
    }
}

// ---------- 5. 停止监听（在 Window.Closing 里调用）----------
public void StopFaceListener()
{
    try { _faceCts?.Cancel(); } catch { }
    try { _faceListener?.Stop(); } catch { }
    try { _faceListener?.Close(); } catch { }
    _faceListener = null;
}

// ---------- 6. 监听循环 ----------
private async Task FaceListenLoop(CancellationToken token)
{
    while (!token.IsCancellationRequested)
    {
        try
        {
            var ctx = await Task.Factory.FromAsync(_faceListener.BeginGetContext, _faceListener.EndGetContext, null);
            _ = Task.Run(() => FaceHandleRequest(ctx));
        }
        catch (ObjectDisposedException) { break; }
        catch { }
    }
}

// ---------- 7. 处理每条推送 ----------
private async Task FaceHandleRequest(HttpListenerContext ctx)
{
    try
    {
        var req = ctx.Request;
        if (req.HttpMethod != "POST") { FaceRespond(ctx, 405, "{\"code\":405}"); return; }

        string body;
        using (var r = new StreamReader(req.InputStream, req.ContentEncoding))
            body = await r.ReadToEndAsync();

        var path = req.Url != null ? req.Url.AbsolutePath : "";
        if (path.IndexOf("/service/event/recordRecognition", StringComparison.OrdinalIgnoreCase) >= 0)
        {
            FaceRespond(ctx, 200, FaceBuildReply(body)); // 必须回执，否则设备会重推
            var info = FaceParse(body);
            if (info != null && info.Status == 1 && info.PassStatus != 0)
            {
                var p = info;
                Dispatcher.Invoke(() => FaceRecognized?.Invoke(p.PersonId, p.PersonNumber, p.Name));
            }
        }
        else
        {
            FaceRespond(ctx, 200, "{\"code\":200,\"msg\":\"success\"}");
        }
    }
    catch
    {
        try { FaceRespond(ctx, 500, "{\"code\":500}"); } catch { }
    }
}

// ---------- 8. 解析识别记录（对应文档 3.2.4）----------
private class FaceRecInfo
{
    public int Status;
    public int PassStatus;
    public string PersonId = "";
    public string PersonNumber = "";
    public string Name = "";
}

private FaceRecInfo FaceParse(string json)
{
    try
    {
        using (var doc = JsonDocument.Parse(json))
        {
            var root = doc.RootElement;
            if (!root.TryGetProperty("params", out var p)) return null;
            return new FaceRecInfo
            {
                Status = FaceGetInt(p, "status"),
                PassStatus = FaceGetInt(p, "passStatus"),
                PersonId = FaceGetStr(p, "personId"),
                PersonNumber = FaceGetStr(p, "personNumber"),
                Name = FaceGetStr(p, "name")
            };
        }
    }
    catch { return null; }
}

// ---------- 9. 构造回执（things.event.post_reply.record:recognition）----------
private string FaceBuildReply(string body)
{
    try
    {
        using (var doc = JsonDocument.Parse(body))
        {
            var root = doc.RootElement;
            var bag = new System.Collections.Generic.Dictionary<string, object>();
            foreach (var prop in root.EnumerateObject())
            {
                if (string.Equals(prop.Name, "method", StringComparison.OrdinalIgnoreCase))
                    bag["method"] = "things.event.post_reply.record:recognition";
                else
                    bag[prop.Name] = prop.Value;
            }
            bag["code"] = 200;
            bag["msg"] = "success";
            return JsonSerializer.Serialize(bag);
        }
    }
    catch { return "{\"code\":200,\"msg\":\"success\"}"; }
}

// ---------- 10. 可选：平台握手，通知设备推送地址（文档 2.2.7）----------
private async Task FaceRegisterToDeviceAsync()
{
    if (string.IsNullOrEmpty(FaceDeviceNum)) return; // 没填序列号就跳过
    try
    {
        var timestamp = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds().ToString();
        var sign = FaceSha256(timestamp + FaceDeviceNum).ToLower();
        var payload = new
        {
            requestId = Guid.NewGuid().ToString("N"),
            timestamp,
            method = "things.action.exec.system:handShake",
            deviceNum = FaceDeviceNum,
            sign,
            @params = new { platformUrl = FacePlatformUrl, platformPort = FaceListenPort, heartbeatTime = 10 }
        };
        var json = JsonSerializer.Serialize(payload);
        using (var client = new HttpClient { Timeout = TimeSpan.FromSeconds(10) })
        {
            var url = "http://" + FaceDeviceIp + ":" + FaceDevicePort + "/service/action/systemHandShake";
            await client.PostAsync(url, new StringContent(json, Encoding.UTF8, "application/json"));
        }
    }
    catch { /* 握手失败可忽略，改在设备 Web 页配置平台地址即可 */ }
}

// ---------- 11. 小工具 ----------
private static void FaceRespond(HttpListenerContext ctx, int code, string json)
{
    var res = ctx.Response;
    res.StatusCode = code;
    res.ContentType = "application/json; charset=utf-8";
    var bytes = Encoding.UTF8.GetBytes(json);
    res.OutputStream.Write(bytes, 0, bytes.Length);
    res.Close();
}

private static string FaceGetStr(JsonElement e, string name)
{
    foreach (var p in e.EnumerateObject())
        if (string.Equals(p.Name, name, StringComparison.OrdinalIgnoreCase))
            return p.Value.ValueKind == JsonValueKind.String ? (p.Value.GetString() ?? "") : p.Value.ToString();
    return "";
}

private static int FaceGetInt(JsonElement e, string name)
{
    foreach (var p in e.EnumerateObject())
        if (string.Equals(p.Name, name, StringComparison.OrdinalIgnoreCase))
            return p.Value.ValueKind == JsonValueKind.Number ? p.Value.GetInt32() : 0;
    return 0;
}

private static string FaceSha256(string input)
{
    using (var sha = SHA256.Create())
    {
        var bytes = sha.ComputeHash(Encoding.UTF8.GetBytes(input));
        var sb = new StringBuilder();
        foreach (var b in bytes) sb.Append(b.ToString("x2"));
        return sb.ToString();
    }
}
