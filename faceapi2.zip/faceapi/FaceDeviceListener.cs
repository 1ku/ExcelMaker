using System;
using System.IO;
using System.Net;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace WpfFaceLogin
{
    /// <summary>
    /// 本地 HTTP 监听服务：接收人脸识别终端推送的识别记录。
    /// 设备识别成功后，会 POST 到 http://&lt;本机IP&gt;:&lt;Port&gt;/service/event/recordRecognition
    /// </summary>
    public class FaceDeviceListener : IDisposable
    {
        private readonly HttpListener _listener = new HttpListener();
        private CancellationTokenSource _cts;

        /// <summary>识别成功事件，参数为解析后的识别记录（已在后台线程触发，UI 需自行 Invoke）</summary>
        public event Action<RecognitionRecord> RecognitionReceived;

        public int Port { get; }

        public FaceDeviceListener(int port)
        {
            Port = port;
            // "+" 表示监听本机所有网卡，设备在内网才能访问到（需要 netsh 授权或以管理员运行）
            _listener.Prefixes.Add($"http://+:{port}/");
        }

        /// <summary>开始监听（异步，非阻塞）</summary>
        public void Start()
        {
            if (_listener.IsListening) return;
            _listener.Start();
            _cts = new CancellationTokenSource();
            _ = Task.Run(() => ListenLoop(_cts.Token));
        }

        private async Task ListenLoop(CancellationToken token)
        {
            while (!token.IsCancellationRequested)
            {
                try
                {
                    var context = await _listener.GetContextAsync();
                    _ = Task.Run(() => HandleRequest(context));
                }
                catch (ObjectDisposedException) { break; }
                catch (Exception) { /* 可在此记录日志 */ }
            }
        }

        private async Task HandleRequest(HttpListenerContext context)
        {
            try
            {
                var req = context.Request;
                if (req.HttpMethod != "POST")
                {
                    Respond(context, 405, "{\"code\":405,\"msg\":\"method not allowed\"}");
                    return;
                }

                string body;
                using (var reader = new StreamReader(req.InputStream, req.ContentEncoding))
                    body = await reader.ReadToEndAsync();

                var path = req.Url?.AbsolutePath ?? "";

                if (path.IndexOf("/service/event/recordRecognition", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    // 设备要求返回 post_reply 回执
                    Respond(context, 200, BuildRecognitionReply(body));

                    var rec = ParseRecord(body);
                    // 只处理“识别成功且放行”的记录
                    if (rec != null && rec.Status == 1 && rec.PassStatus != 0)
                    {
                        RecognitionReceived?.Invoke(rec);
                    }
                }
                else
                {
                    // 其它事件（心跳等）统一回 200
                    Respond(context, 200, "{\"code\":200,\"msg\":\"success\"}");
                }
            }
            catch
            {
                try { Respond(context, 500, "{\"code\":500,\"msg\":\"error\"}"); } catch { }
            }
        }

        private RecognitionRecord ParseRecord(string json)
        {
            try
            {
                using var doc = JsonDocument.Parse(json);
                var root = doc.RootElement;
                if (!root.TryGetProperty("params", out var p)) return null;

                return new RecognitionRecord
                {
                    Method = JsonHelper.GetStr(root, "method"),
                    TaskId = JsonHelper.GetStr(p, "taskId"),
                    Status = JsonHelper.GetInt(p, "status"),
                    PassStatus = JsonHelper.GetInt(p, "passStatus"),
                    PersonId = JsonHelper.GetStr(p, "personId"),
                    PersonIdType = JsonHelper.GetInt(p, "personIdType"),
                    PersonNumber = JsonHelper.GetStr(p, "personNumber"),
                    Name = JsonHelper.GetStr(p, "name"),
                    Time = JsonHelper.GetStr(p, "time"),
                    CardNumber = JsonHelper.GetStr(p, "cardNumber")
                };
            }
            catch { return null; }
        }

        /// <summary>按文档回执格式构造 things.event.post_reply.record:recognition</summary>
        private string BuildRecognitionReply(string body)
        {
            try
            {
                using var doc = JsonDocument.Parse(body);
                var root = doc.RootElement;
                var bag = new System.Collections.Generic.Dictionary<string, object>();
                foreach (var prop in root.EnumerateObject())
                {
                    if (string.Equals(prop.Name, "method", StringComparison.OrdinalIgnoreCase))
                        bag["method"] = "things.event.post_reply.record:recognition";
                    else
                        bag[prop.Name] = prop.Value;
                }
                bag["code"] = 200;
                bag["msg"] = "success";
                return JsonSerializer.Serialize(bag);
            }
            catch
            {
                return "{\"code\":200,\"msg\":\"success\"}";
            }
        }

        private static void Respond(HttpListenerContext context, int code, string json)
        {
            var res = context.Response;
            res.StatusCode = code;
            res.ContentType = "application/json; charset=utf-8";
            var bytes = Encoding.UTF8.GetBytes(json);
            res.OutputStream.Write(bytes, 0, bytes.Length);
            res.Close();
        }

        public void Dispose()
        {
            try { _cts?.Cancel(); } catch { }
            try { _listener.Stop(); } catch { }
            try { _listener.Close(); } catch { }
            _cts?.Dispose();
        }
    }
}
