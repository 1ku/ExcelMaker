# WPF 人脸识别登录（接收设备推送的账号 ID）

## 用到的接口
文档第 **3.2.4 节「识别记录上报」**：设备刷脸识别成功后，会 **POST**
`http://<本机IP>:<端口>/service/event/recordRecognition`
一条 JSON 给你，关键字段：

| 字段 | 含义 | 说明 |
|------|------|------|
| `personId` | 人员 ID | 设备里的“账号 id” |
| `personNumber` | 人员编号（工号） | 常作为登录账号 |
| `name` | 姓名 | |
| `status` | 识别状态 | 0 失败 / 1 成功 |
| `passStatus` | 通行状态 | 0 失败 / 1 成功 / 2 平台决策 |

## 让设备知道“推送到哪”（二选一）
设备必须知道你的 WPF 地址，否则监听了也收不到：

**方式 A（推荐，最简单）：设备 Web 管理页配置**
浏览器打开 `http://192.168.252.111:8098`，在“第三方平台/平台地址”里填
`你的电脑局域网IP:8088`（例：`192.168.252.50:8088`），保存。

**方式 B：代码握手**
`LoginWindow.xaml.cs` 里已调用 `FaceDeviceClient.HandShakeAsync(...)`，
会用文档 2.2.7「平台握手」接口通知设备。需要填对 `DeviceNum`（设备序列号，
在设备机身或 Web 页查看）。签名按文档 2.4：`SHA256(timestamp+deviceNum)`。

## 权限与防火墙（很重要）
`HttpListener` 绑定 `http://+:<端口>/` 需要授权，否则报“拒绝访问(5)”：
1. 以**管理员身份**运行一次程序；或
2. 用管理员打开 cmd 执行（端口改成你的）：
   ```
   netsh http add urlacl url=http://+:8088/ user=Everyone
   ```
3. Windows 防火墙放行 8088 入站（专用/公用网络按需）。

## 确认你能收到数据（自测）
另开一个工具（如 Postman / curl）向本机发一条模拟推送：
```
curl -X POST http://localhost:8088/service/event/recordRecognition ^
 -H "Content-Type: application/json" ^
 -d "{\"method\":\"things.event.post.record:recognition\",\"params\":{\"status\":1,\"passStatus\":1,\"personId\":\"P123\",\"personNumber\":\"10086\",\"name\":\"张三\",\"time\":\"2026-07-30 10:00:00:123\"}}"
```
窗口应出现“张三 / 10086 / P123”。

## personId 还是 personNumber？
- 文档把 `personId` 叫“人员 id”，更接近你说的“账号 id”。
- 很多场景下真正拿去登录的是 `personNumber`（工号）。
- 代码里两个都回填到界面了，`DoLogin(...)` 默认用 `AccountBox`（工号）；
  想用 `personId` 就把 `LoginBtn_Click` / `OnRecognition` 里的参数改成 `PersonIdBox.Text`。
