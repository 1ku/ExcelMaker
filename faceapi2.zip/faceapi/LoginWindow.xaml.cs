using System;
using System.ComponentModel;
using System.Windows;

namespace WpfFaceLogin
{
    public partial class LoginWindow : Window
    {
        // ====== 按需修改这里的配置 ======
        /// <summary>本机监听端口，必须和设备里配置的“第三方平台端口”一致</summary>
        private const int ListenPort = 8088;

        /// <summary>设备 IP（你提供的）</summary>
        private const string DeviceIp = "192.168.252.111";

        /// <summary>设备端口（你提供的）</summary>
        private const int DevicePort = 8098;

        /// <summary>本机局域网 IP（替换成你电脑在 192.168.252.x 网段的真实 IP）</summary>
        private const string MyLanIp = "192.168.252.50";

        /// <summary>设备序列号（可选：仅在调用握手接口时需要，Web 管理页配置则不需要）</summary>
        private const string DeviceNum = "B0100120210221900001";

        // ===============================

        private FaceDeviceListener _listener;

        public LoginWindow()
        {
            InitializeComponent();
            Loaded += LoginWindow_Loaded;
            Closing += LoginWindow_Closing;
        }

        private async void LoginWindow_Loaded(object sender, RoutedEventArgs e)
        {
            // 1) 启动本地 HTTP 监听，等刷脸推送
            _listener = new FaceDeviceListener(ListenPort);
            _listener.RecognitionReceived += OnRecognition;
            try
            {
                _listener.Start();
                StatusText.Text = $"已启动监听：http://+:{ListenPort}/service/event/recordRecognition";
            }
            catch (System.Net.HttpListenerException ex) when (ex.ErrorCode == 5)
            {
                StatusText.Text = "监听失败：权限不足。请右键“以管理员身份运行”，或先执行 netsh 授权（见说明）。";
                return;
            }

            // 2) 可选：通知设备把识别记录推送到本机（若已在设备 Web 页配好可注释掉）
            try
            {
                bool ok = await FaceDeviceClient.HandShakeAsync(DeviceIp, DevicePort, MyLanIp, ListenPort, DeviceNum);
                StatusText.Text += ok ? "  | 握手成功" : "  | 握手失败（可改用设备 Web 页配置）";
            }
            catch (Exception ex)
            {
                StatusText.Text += $"  | 握手异常：{ex.Message}（可改用设备 Web 页配置）";
            }
        }

        /// <summary>刷脸推送到达（后台线程触发，需切回 UI 线程）</summary>
        private void OnRecognition(RecognitionRecord rec)
        {
            Dispatcher.Invoke(() =>
            {
                PersonIdBox.Text = rec.PersonId;   // 人员ID（账号id）
                AccountBox.Text = rec.PersonNumber; // 工号
                NameBox.Text = rec.Name;
                StatusText.Text = $"[{rec.Time}] 识别成功：{rec.Name}（{rec.PersonNumber}）";

                // ===== 想直接拿 personId 当账号自动登录，打开下面这行 =====
                // DoLogin(rec.PersonId);
            });
        }

        private void LoginBtn_Click(object sender, RoutedEventArgs e)
        {
            // 点按钮时用手账号框里的 personNumber；若想用 personId 改成 PersonIdBox.Text
            DoLogin(AccountBox.Text);
        }

        private void DoLogin(string accountId)
        {
            if (string.IsNullOrWhiteSpace(accountId))
            {
                MessageBox.Show("尚未识别到人脸账号");
                return;
            }
            // 这里接你原来的登录逻辑，例如：
            MessageBox.Show($"用人脸账号登录：{accountId}");
            // YourLoginService.LoginByFace(accountId);
        }

        private void LoginWindow_Closing(object sender, CancelEventArgs e)
        {
            _listener?.Dispose();
        }
    }
}
